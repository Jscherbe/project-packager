// This is a file in a package
console.log("hello world");